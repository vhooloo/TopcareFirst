# jQuery Bootstrap-style Dropdowns #

Copyright 2013 Cory LaViska for [A Beautiful Site, LLC.](http://abeautifulsite.net/)

Licensed under the MIT license: http://opensource.org/licenses/MIT

## Demo & Documentation ##

http://labs.abeautifulsite.net/jquery-dropdown/